
import { BarcodeScanner, BarcodeFormat } from '@capacitor-mlkit/barcode-scanning';

const button = document.getElementById('scanBarcodeBtn');
if (button) {
  button.addEventListener('click', async () => {
    const isNative = !!window.Capacitor?.isNativePlatform?.();
    if (!isNative) {
      alert(document.documentElement.lang === 'ar'
        ? 'قارئ الباركود يعمل داخل تطبيق Android APK. افتح التطبيق على الهاتف.'
        : 'Le scanner fonctionne dans l’application Android APK.');
      return;
    }
    try {
      const supported = await BarcodeScanner.isSupported();
      if (!supported.supported) {
        alert('Barcode scanning is not supported on this device.');
        return;
      }
      const permission = await BarcodeScanner.requestPermissions();
      if (permission.camera !== 'granted') {
        alert('Camera permission is required to scan a barcode.');
        return;
      }
      const result = await BarcodeScanner.scan({
        formats: [
          BarcodeFormat.QrCode,
          BarcodeFormat.Code128,
          BarcodeFormat.Code39,
          BarcodeFormat.Ean13,
          BarcodeFormat.Ean8,
          BarcodeFormat.UpcA,
          BarcodeFormat.UpcE,
          BarcodeFormat.Pdf417,
          BarcodeFormat.DataMatrix
        ]
      });
      const value = result.barcodes?.[0]?.rawValue?.trim();
      if (value) {
        const field = document.getElementById('serviceTag');
        field.value = value;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.focus();
      }
    } catch (error) {
      console.error('Barcode scan failed:', error);
      alert('Scan failed. Please try again.');
    }
  });
}
