import { defineConfig } from 'vite';
export default defineConfig({
  root: 'www',
  build: {
    outDir: '../dist',
    emptyOutDir: true,
    target: 'es2020'
  }
});
