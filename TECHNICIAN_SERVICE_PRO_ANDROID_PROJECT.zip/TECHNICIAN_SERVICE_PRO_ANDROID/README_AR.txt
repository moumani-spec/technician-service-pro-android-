TECHNICIAN SERVICE PRO — ANDROID PROJECT
MR SOLUTION

هذا مشروع Android جاهز للفتح والبناء عبر Android Studio باستخدام Capacitor.

المزايا المضافة في هذه الحزمة:
- نسخة الهاتف هي التطبيق الرئيسي.
- 4 مظاهر: Dark Pro وLight Pro وMidnight وBlue Glass.
- حفظ المظهر المختار على الهاتف.
- زر Scan لقراءة QR وCode 128 وCode 39 وEAN وغيرها بواسطة كاميرا الهاتف.
- نتيجة المسح توضع في خانة Service Tag.
- الواجهة الحالية وبيانات الورشة وشعار MR SOLUTION موروثة من V11.

متطلبات البناء:
- Node.js LTS
- Android Studio
- Android SDK
- اتصال بالإنترنت أول مرة لتنزيل الحزم.

خطوات البناء على Windows:
1) فك ضغط ZIP.
2) افتح CMD داخل مجلد المشروع.
3) نفّذ:
   npm install
   npm run build
   npx cap add android
   npx cap sync android
   npx cap open android
4) داخل Android Studio انتظر Gradle Sync.
5) اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
6) ستجد APK في:
   android/app/build/outputs/apk/debug/app-debug.apk

ملاحظات:
- هذه حزمة مصدر Android وليست APK مبنياً مسبقاً.
- أول تشغيل يحتاج تنزيل المكتبات.
- بيانات V11 الحالية محفوظة محلياً في تخزين التطبيق/المتصفح. لم تتم إضافة مزامنة هاتف-Windows أو خادم مركزي بعد.
- قارئ الباركود يحتاج إذن الكاميرا ويعمل داخل APK على Android.
- جرّب النسخة على جهاز فعلي قبل اعتمادها للعمل اليومي، واحتفظ بنسخة احتياطية من البيانات.
